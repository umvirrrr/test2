# Swing Overview

Swing is a Java framework for building graphical user interfaces (GUIs). It is part of the Java Foundation Classes (JFC) and provides a rich set of components such as buttons, text fields, tables, and windows. Swing is lightweight, platform-independent, and highly customizable.

Swing applications often follow the Model-View-Controller (MVC) architectural pattern. In our cash register example:
- **Model**: `CashRegister`, `Product` – manage data and business logic.
- **View**: `Display` – shows scanned items and subtotal.
- **Controller**: `Controller2` – connects user actions (button clicks) with model updates and view refreshes.

This separation improves maintainability, testability, and clarity in GUI applications.
